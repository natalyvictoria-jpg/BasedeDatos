package mx.edu.utng.mdp.database.ui.theme.viewmodel

class PostViewmodel {
}