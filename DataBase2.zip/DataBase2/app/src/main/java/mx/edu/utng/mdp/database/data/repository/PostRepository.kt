package mx.edu.utng.mdp.database.data.repository

class PostRepository {
}