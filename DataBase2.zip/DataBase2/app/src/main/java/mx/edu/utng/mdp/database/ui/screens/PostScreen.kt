package mx.edu.utng.mdp.database.ui.screens

import mx.edu.utng.mdp.database.data.local.dao.PostDao

class PostScreen(postDao: PostDao) {
}