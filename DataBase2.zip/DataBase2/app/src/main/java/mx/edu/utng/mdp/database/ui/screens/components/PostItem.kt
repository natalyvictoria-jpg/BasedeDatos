package mx.edu.utng.mdp.database.ui.screens.components

class PostItem {
}