package mx.edu.utng.nvg.database.data.repository

class PostRepository {
}