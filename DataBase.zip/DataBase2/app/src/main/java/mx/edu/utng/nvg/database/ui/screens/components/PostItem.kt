package mx.edu.utng.nvg.database.ui.screens.components

class PostItem {
}