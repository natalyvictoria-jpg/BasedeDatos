package mx.edu.utng.nvg.database.ui.screens

import mx.edu.utng.nvg.database.data.local.dao.PostDao

class PostScreen(postDao: PostDao) {
}