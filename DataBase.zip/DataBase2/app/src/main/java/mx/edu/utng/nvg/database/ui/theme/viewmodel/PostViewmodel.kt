package mx.edu.utng.nvg.database.ui.theme.viewmodel

class PostViewmodel {
}